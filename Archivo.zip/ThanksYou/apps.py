from django.apps import AppConfig


class ThanksyouConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ThanksYou'
